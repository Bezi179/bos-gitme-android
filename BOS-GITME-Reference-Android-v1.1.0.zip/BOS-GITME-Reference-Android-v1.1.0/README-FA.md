# BOŞ GİTME — Reference Android v1.1.0

این پروژه، باندل وبِ استخراج‌شده از APK مرجع کاربر را بدون بازطراحی در یک پوسته Android مبتنی بر Capacitor قرار می‌دهد.

## ساخت APK با GitHub Actions
1. محتویات این ZIP را در ریشه مخزن GitHub قرار دهید (فایل ZIP را به‌تنهایی آپلود نکنید).
2. مطمئن شوید پوشه‌های `www` و `.github/workflows` و فایل‌های `package.json` و `capacitor.config.ts` در ریشه مخزن هستند.
3. به Actions بروید و `Build BOŞ GİTME Reference Android APK` را اجرا کنید.
4. پس از موفقیت، از Artifacts فایل `BOS-GITME-Reference-Android-debug` را دانلود و از حالت ZIP خارج کنید؛ `app-debug.apk` قابل نصب است.

## وضعیت عملکرد
- رابط کاربری: باندل اصلی استخراج‌شده از APK مرجع.
- پوسته اندروید: Capacitor.
- این بسته به‌تنهایی Backend یا API عملیاتی ایجاد نمی‌کند. در باندل، مسیرهای `/api/...` وجود دارند و آدرس API از `localStorage` با کلید `bg_api_base_url` یا متغیر `window.__BOS_GITME_DEFAULT_API__` خوانده می‌شود.
- تا زمان استقرار Backend و تنظیم آدرس API، ورود، OTP، سفارش زنده، پیام‌رسانی، ذخیره‌سازی سمت سرور و عملیات حساس عملیاتی نیستند.
- APK خروجی این workflow نسخه Debug است و برای آزمایش/نصب داخلی مناسب است؛ انتشار عمومی نیازمند امضای Release و تنظیم کلید امضاست.

## نکته درباره منبع
فایل‌های `www/assets/*.js` و `*.css` باندل production استخراج‌شده‌اند، نه سورس اصلی React/TypeScript. ظاهر و رفتار تعبیه‌شده حفظ می‌شود، اما توسعه ساختاری بعدی به بازسازی سورس نیاز دارد.
