import 'package:flutter/material.dart';

void main() => runApp(const BosGitmeApp());

class BosGitmeApp extends StatelessWidget {
  const BosGitmeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BOŞ GİTME',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087E70)),
        scaffoldBackgroundColor: const Color(0xFFF5F7F7),
        fontFamily: 'Roboto',
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  final pages = const [DashboardPage(), AvailabilityPage(), LoadsPage(), ProfilePage()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.local_shipping_outlined), label: 'آمادگی'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'بارها'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'پروفایل'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(20), children: [
      Row(children: [
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('BOŞ GİTME', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 1)),
          SizedBox(height: 4),
          Text('خالی نرو، پُربار برگرد', style: TextStyle(color: Colors.black54)),
        ])),
        CircleAvatar(backgroundColor: const Color(0xFFE1F2EF), child: Icon(Icons.local_shipping, color: Color(0xFF087E70))),
      ]),
      const SizedBox(height: 24),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF075E55), Color(0xFF0A9B83)]),
          borderRadius: BorderRadius.circular(22),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('بار برگشتی پیدا کن', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('به صاحبان بار متصل شو و مسیر برگشتت را پربار کن.', style: TextStyle(color: Colors.white70, height: 1.5)),
          SizedBox(height: 18),
          Row(children: [
            Icon(Icons.flag, color: Colors.white), SizedBox(width: 8),
            Text('ایران  ←  ترکیه', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          ]),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('دسترسی سریع', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _QuickCard(icon: Icons.add_road, title: 'اعلام آمادگی', subtitle: 'مسیر و زمان حرکت')),
        const SizedBox(width: 12),
        Expanded(child: _QuickCard(icon: Icons.search, title: 'جست‌وجوی بار', subtitle: 'بارهای موجود')),
      ]),
      const SizedBox(height: 22),
      const _InfoCard(icon: Icons.verified_user_outlined, title: 'احراز هویت راننده', text: 'برای ارسال درخواست نهایی بار، حساب راننده باید تأیید شود.'),
      const SizedBox(height: 12),
      const _InfoCard(icon: Icons.language, title: 'سه‌زبانه', text: 'نسخه محصول برای فارسی، ترکی استانبولی و انگلیسی طراحی می‌شود.'),
      const SizedBox(height: 18),
      const Text('نسخه نمایشی رابط کاربری', style: TextStyle(color: Colors.black45, fontSize: 12)),
    ]);
  }
}

class _QuickCard extends StatelessWidget {
  final IconData icon; final String title; final String subtitle;
  const _QuickCard({required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: const Color(0xFF087E70), size: 28),
      const SizedBox(height: 12),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12)),
    ]),
  );
}

class _InfoCard extends StatelessWidget {
  final IconData icon; final String title; final String text;
  const _InfoCard({required this.icon, required this.title, required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: const Color(0xFF087E70)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        Text(text, style: const TextStyle(color: Colors.black54, height: 1.4)),
      ])),
    ]),
  );
}

class AvailabilityPage extends StatelessWidget {
  const AvailabilityPage({super.key});
  @override
  Widget build(BuildContext context) => const _PlaceholderPage(
    title: 'اعلام آمادگی برای بار برگشتی',
    icon: Icons.local_shipping_outlined,
    description: 'در نسخه عملیاتی، راننده وسیله نقلیه، شهر فعلی، مقصد، زمان آمادگی و ظرفیت را ثبت می‌کند.',
    button: 'ثبت اعلام آمادگی',
  );
}

class LoadsPage extends StatelessWidget {
  const LoadsPage({super.key});
  @override
  Widget build(BuildContext context) => const _PlaceholderPage(
    title: 'بارهای قابل درخواست',
    icon: Icons.inventory_2_outlined,
    description: 'بارهای تأییدشده متناسب با مسیر و نوع تریلی اینجا نمایش داده می‌شوند.',
    button: 'به‌روزرسانی بارها',
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => const _PlaceholderPage(
    title: 'پروفایل راننده',
    icon: Icons.person_outline,
    description: 'اطلاعات هویتی، شماره تماس، کشنده، تریلی و مدارک راننده در این بخش مدیریت می‌شود.',
    button: 'تکمیل پروفایل',
  );
}

class _PlaceholderPage extends StatelessWidget {
  final String title, description, button; final IconData icon;
  const _PlaceholderPage({required this.title, required this.description, required this.button, required this.icon});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 64, color: const Color(0xFF087E70)),
        const SizedBox(height: 18),
        Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Text(description, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, height: 1.6)),
        const SizedBox(height: 22),
        FilledButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('این قابلیت در نسخه بعدی متصل می‌شود.')),
        ), child: Text(button)),
      ]),
    ),
  );
}
